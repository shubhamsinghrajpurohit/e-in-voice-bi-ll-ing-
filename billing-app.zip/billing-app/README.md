# Billing Ledger

A small business invoicing app — clients, invoices, line items, tax, and a
printable receipt-style invoice view. Data is saved in the browser
(`localStorage`), per device.

## Run locally

```bash
npm install
npm run dev
```

Open the URL it prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

Output goes to `dist/`. Preview it locally with `npm run preview`.

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

(Create the empty repo on GitHub first, then run the commands above from
this folder.)

## Deploy

**Vercel**
1. Go to vercel.com → New Project → import your GitHub repo
2. Framework preset: Vite (auto-detected)
3. Deploy — no config needed

**Netlify**
1. Go to netlify.com → Add new site → Import from GitHub
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Deploy

Either platform gives you a free `*.vercel.app` / `*.netlify.app` URL
immediately, and both let you attach a custom domain afterward under
Project Settings → Domains — just add your domain and update the DNS
records they show you at your registrar.

## Notes

- Data is stored per-browser via `localStorage`, not synced across
  devices. For multi-device or multi-user access, swap `src/storage.js`
  for a backend (e.g. Supabase or Firebase).
